To run this script, open pymol and use the command prompt to navigate to the directory containing:
1) the script (Figure_3_source_code_1.py), 
2) the preferences file (Supplemental_File_2_HApreferences_rescaled.txt),
3) the PDB file (1RVX_trimer_sequentialnumbering.pdb).

Then run the script by typing:
run Figure_3_source_code_1.py